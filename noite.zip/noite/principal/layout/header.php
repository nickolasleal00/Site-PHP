<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Portal News</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="topo">
    <div class="top-left">
        <input type="text" placeholder="Buscar..." class="campo-busca">
    </div>

    <div class="logo">
        <h1>PortalNews</h1>
    </div>

    <div class="top-right">
        <a href="../banco/index.php" class="btn-login">Entrar</a>
        <a href="#" class="btn-assinar">Assinar</a>
    </div>
</header>

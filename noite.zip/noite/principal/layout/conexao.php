<?php
$host = "localhost";
$userDb = "root";
$passDb = "";
$nameDb = "portal"; 


$conexao = mysqli_connect($host, $userDb, $passDb, $nameDb);
if (mysqli_connect_errno()) {
    die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
}
mysqli_set_charset($conexao, "utf8mb4");
?>
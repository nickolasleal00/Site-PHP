<nav class="menu">
    <a href="#inicio">Início</a>
    <a href="#noticias">Notícias</a>
    <a href="#mundo">Mundo</a>
    <a href="#esportes">Esportes</a>
    <a href="#cultura">Cultura</a>
    <a href="#economia">Economia</a>
</nav>

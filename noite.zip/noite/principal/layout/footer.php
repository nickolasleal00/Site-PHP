<footer class="rodape">
    <h2>PortalNews</h2>

    <div class="social">
        <a href="#">Twitter</a>
        <a href="#">Facebook</a>
        <a href="#">Instagram</a>
    </div>

    <div class="links-footer">
        <a href="#">Sobre</a>
        <a href="#">Equipe</a>
        <a href="#">Arquivo</a>
        <a href="#">Termos</a>
        <a href="#">Privacidade</a>
    </div>
</footer>

</body>
</html>

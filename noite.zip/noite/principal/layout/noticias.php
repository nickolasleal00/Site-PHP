<?php include "layout/header.php"; ?>
<?php include "layout/navbar.php"; ?>

<section class="conteudo">
    <h1 style="padding-left: 40px;">Notícias Gerais</h1>

    <p style="padding-left: 40px;">Aqui você pode listar notícias reais, ou virá do banco de dados mais tarde.</p>

</section>

<?php include "layout/footer.php"; ?>

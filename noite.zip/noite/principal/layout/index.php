<?php include "header.php"; ?>
<?php include "navbar.php"; ?>

<link rel="stylesheet" href="style.css">

<?php include "conexao.php"; ?>

<section id="inicio" class="conteudo bloco">
    <div class="grid-noticias">
        
        <?php
        $sql = "SELECT titulo, categoria, caminho_imagem, data_publicacao FROM noticias ORDER BY data_publicacao DESC LIMIT 6";
        $resultado = $conexao->query($sql);

        if ($resultado && $resultado->num_rows > 0):
            while($noticia = $resultado->fetch_assoc()):
                $data_formatada = date('d/m/Y', strtotime($noticia['data_publicacao']));
        ?>
        
        <div class="card card-inicio">
            <div class="destaque-topo">
                <small><?php echo htmlspecialchars(ucfirst($noticia['categoria'])); ?></small>
            </div>
            
            <div class="img-container"> 
                <img src="<?php echo htmlspecialchars($noticia['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($noticia['titulo']); ?>">
            </div>
            
            <h3><?php echo htmlspecialchars($noticia['titulo']); ?></h3>
            <p>Publicado em: <?php echo $data_formatada; ?></p>
        </div>
        
        <?php
            endwhile;
        else:
            echo "<p style='text-align: center; grid-column: 1 / -1;'>Nenhuma notícia recente encontrada.</p>";
        endif;
        ?>

    </div>
</section>


<section id="noticias" class="conteudo bloco">
    <div class="grid-noticias">
        <?php
        $sql_cat = "SELECT titulo, caminho_imagem, data_publicacao FROM noticias WHERE categoria = 'noticias' ORDER BY data_publicacao DESC LIMIT 4";
        $resultado_cat = $conexao->query($sql_cat);

        if ($resultado_cat && $resultado_cat->num_rows > 0):
            while($noticia_cat = $resultado_cat->fetch_assoc()):
        ?>
        <div class="card card-noticias">
            <div class="destaque-topo">
                <small>Notícias</small>
            </div>
            <div class="img-container">
                <img src="<?php echo htmlspecialchars($noticia_cat['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($noticia_cat['titulo']); ?>">
            </div>
            <h3><?php echo htmlspecialchars($noticia_cat['titulo']); ?></h3>
            <p>Atualizado em: <?php echo date('d/m/Y', strtotime($noticia_cat['data_publicacao'])); ?></p>
        </div>
        <?php
            endwhile;
        else:
             echo "<p style='text-align: center; grid-column: 1 / -1;'>Nenhuma notícia na categoria Notícias.</p>";
        endif;
        ?>
    </div>
</section>


<section id="mundo" class="conteudo bloco">
    <div class="grid-noticias">
        <?php
        $sql_cat = "SELECT titulo, caminho_imagem, data_publicacao FROM noticias WHERE categoria = 'mundo' ORDER BY data_publicacao DESC LIMIT 4";
        $resultado_cat = $conexao->query($sql_cat);

        if ($resultado_cat && $resultado_cat->num_rows > 0):
            while($noticia_cat = $resultado_cat->fetch_assoc()):
        ?>
        <div class="card card-mundo">
            <div class="destaque-topo">
                <small>Mundo</small>
            </div>
            <div class="img-container">
                <img src="<?php echo htmlspecialchars($noticia_cat['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($noticia_cat['titulo']); ?>">
            </div>
            <h3><?php echo htmlspecialchars($noticia_cat['titulo']); ?></h3>
            <p>Publicado em: <?php echo date('d/m/Y', strtotime($noticia_cat['data_publicacao'])); ?></p>
        </div>
        <?php
            endwhile;
        else:
             echo "<p style='text-align: center; grid-column: 1 / -1;'>Nenhuma notícia na categoria Mundo.</p>";
        endif;
        ?>
    </div>
</section>

<section id="esportes" class="conteudo bloco">
    <div class="grid-noticias">
        <?php
        $sql_cat = "SELECT titulo, caminho_imagem, data_publicacao FROM noticias WHERE categoria = 'esportes' ORDER BY data_publicacao DESC LIMIT 4";
        $resultado_cat = $conexao->query($sql_cat);

        if ($resultado_cat && $resultado_cat->num_rows > 0):
            while($noticia_cat = $resultado_cat->fetch_assoc()):
        ?>
        <div class="card card-esportes">
            <div class="destaque-topo">
                <small>Esportes</small>
            </div>
            <div class="img-container">
                <img src="<?php echo htmlspecialchars($noticia_cat['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($noticia_cat['titulo']); ?>">
            </div>
            <h3><?php echo htmlspecialchars($noticia_cat['titulo']); ?></h3>
            <p>Publicado em: <?php echo date('d/m/Y', strtotime($noticia_cat['data_publicacao'])); ?></p>
        </div>
        <?php
            endwhile;
        else:
             echo "<p style='text-align: center; grid-column: 1 / -1;'>Nenhuma notícia na categoria Esportes.</p>";
        endif;
        ?>
    </div>
</section>

<section id="cultura" class="conteudo bloco">
    <div class="grid-noticias">
        <?php
        $sql_cat = "SELECT titulo, caminho_imagem, data_publicacao FROM noticias WHERE categoria = 'cultura' ORDER BY data_publicacao DESC LIMIT 4";
        $resultado_cat = $conexao->query($sql_cat);

        if ($resultado_cat && $resultado_cat->num_rows > 0):
            while($noticia_cat = $resultado_cat->fetch_assoc()):
        ?>
        <div class="card card-cultura">
            <div class="destaque-topo">
                <small>Cultura</small>
            </div>
            <div class="img-container">
                <img src="<?php echo htmlspecialchars($noticia_cat['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($noticia_cat['titulo']); ?>">
            </div>
            <h3><?php echo htmlspecialchars($noticia_cat['titulo']); ?></h3>
            <p>Publicado em: <?php echo date('d/m/Y', strtotime($noticia_cat['data_publicacao'])); ?></p>
        </div>
        <?php
            endwhile;
        else:
             echo "<p style='text-align: center; grid-column: 1 / -1;'>Nenhuma notícia na categoria Cultura.</p>";
        endif;
        ?>
    </div>
</section>

<section id="economia" class="conteudo bloco">
    <div class="grid-noticias">
        <?php
        $sql_cat = "SELECT titulo, caminho_imagem, data_publicacao FROM noticias WHERE categoria = 'economia' ORDER BY data_publicacao DESC LIMIT 4";
        $resultado_cat = $conexao->query($sql_cat);

        if ($resultado_cat && $resultado_cat->num_rows > 0):
            while($noticia_cat = $resultado_cat->fetch_assoc()):
        ?>
        <div class="card card-economia">
            <div class="destaque-topo">
                <small>Economia</small>
            </div>
            <div class="img-container">
                <img src="<?php echo htmlspecialchars($noticia_cat['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($noticia_cat['titulo']); ?>">
            </div>
            <h3><?php echo htmlspecialchars($noticia_cat['titulo']); ?></h3>
            <p>Publicado em: <?php echo date('d/m/Y', strtotime($noticia_cat['data_publicacao'])); ?></p>
        </div>
        <?php
            endwhile;
        else:
             echo "<p style='text-align: center; grid-column: 1 / -1;'>Nenhuma notícia na categoria Economia.</p>";
        endif;
        
        $conexao->close();
        ?>
    </div>
</section>


<?php include "footer.php"; ?>
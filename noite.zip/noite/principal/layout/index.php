<?php 
    include "header.php"; 
    include "navbar.php";


    echo '<link rel="stylesheet" href="style.css">';


    include "conexao.php";


    if (!$conexao) {
        die("<h2 style='color:red; text-align:center;'>Erro ao conectar ao banco de dados!</h2>");
    }

    function gerarCards($conexao, $categoria, $tituloSecao, $limite = 3) {


        if ($categoria == "inicio") {
            $sql = "SELECT titulo, categoria, caminho_imagem, data_publicacao 
                    FROM noticias 
                    ORDER BY data_publicacao DESC 
                    LIMIT $limite";
        } else {
            $sql = "SELECT titulo, caminho_imagem, data_publicacao 
                    FROM noticias 
                    WHERE LOWER(categoria) = LOWER('$categoria')
                    ORDER BY data_publicacao DESC 
                    LIMIT $limite";
        }

        $resultado = $conexao->query($sql);

        echo "<section id='$categoria' class='conteudo bloco'>";
        echo "<h2 class='titulo-secao'>$tituloSecao</h2>";
        echo "<div class='grid-noticias'>";

        if ($resultado && $resultado->num_rows > 0):

            while($not = $resultado->fetch_assoc()):

                $temImagem = !empty($not['caminho_imagem']);

                $data = date('d/m/Y', strtotime($not['data_publicacao']));
                
?>


            <div class="card">
                <div class="destaque-topo">
                    <small><?php echo htmlspecialchars(ucfirst($categoria == "inicio" ? $not["categoria"] : $categoria)); ?></small>
                </div>

                <div class="img-container <?php echo $temImagem ? '' : 'sem-imagem'; ?>"> 
                    <?php if ($temImagem): ?>
                        <img src="<?php echo htmlspecialchars($not['caminho_imagem']); ?>" 
                             alt="<?php echo htmlspecialchars($not['titulo']); ?>">
                    <?php endif; ?>
                </div>

                <h3><?php echo htmlspecialchars($not['titulo']); ?></h3>
                <p>Publicado em: <?php echo $data; ?></p>
            </div>

<?php
            endwhile;

        else:
            echo "<p style='grid-column:1/-1; text-align:center;'>Nenhuma notícia encontrada.</p>";
        endif;

        echo "</div>";
        echo "</section>";
    }
?>



<?php
gerarCards($conexao, "inicio", "Últimas Notícias", 3);
gerarCards($conexao, "noticias", "Notícias");
gerarCards($conexao, "mundo", "Mundo");
gerarCards($conexao, "esportes", "Esportes");
gerarCards($conexao, "cultura", "Cultura");
gerarCards($conexao, "economia", "Economia");

$conexao->close();
?>

<?php include "footer.php"; ?>

<?php 
$host = "localhost";
$userDb = "root";
$passDb = "";
$nameDb = "portal";
$conecta = mysqli_connect($host, $userDb, $passDb, $nameDb);

function login($conecta){
    if (isset($_POST['logar'])) {
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        $senha = sha1($_POST['senha']); 

        if (!empty($email)) {

            $sql = "SELECT * FROM usuarios WHERE email = '$email' AND senha = '$senha' ";
            $action = mysqli_query($conecta, $sql);
            $result = mysqli_fetch_assoc($action);

            if (!empty($result['email'])) {
                session_start();
                $_SESSION['nome'] = !empty($result['nome']) ? $result['nome'] : "Usuário";
                $_SESSION['email'] = $result['email']; 
                $_SESSION['ativa'] = true;
                header("location: ../admin/admin.php");
            } else {
                echo "E-mail ou senha incorretos!";
            }
        } else {
            echo "Preencha seu e-mail ou senha corretamente!";
        }
    }
}

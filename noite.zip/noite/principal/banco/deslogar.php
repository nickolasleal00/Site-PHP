<?php
session_start();

//Limpa caches da session
session_unset();

//Deslogar
session_destroy();

//Redirecionamos para a página de login
header("location: index.php");
<?php require_once "functions.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login e Senha</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #004aad, #00a6ff);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background: #fff;
            padding: 40px 35px;
            width: 350px;
            border-radius: 12px;
            box-shadow: 0px 0px 20px rgba(0,0,0,0.2);
            text-align: center;
        }
        .container a {
            background: #6a0dad; 
            padding: 12px 20px; 
            border-radius: 12px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
            text-align: center;
            color: white;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
            font-weight: 600;
            font-size: 16px;
        }

        .container a:hover {
            background: #4b0082; 
        }

        .container h2 {
            margin-bottom: 25px;
            color: #333;
        }

        label {
            display: block;
            text-align: left;
            margin-top: 15px;
            font-weight: bold;
            color: #444;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 15px;
        }

        button {
            margin-top: 25px;
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s ease;
        }

        button:hover {
            background-color: #005fcc;
        }

        .erro {
            margin-top: 15px;
            color: #d60000;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Acesso ao Painel</h2>

        <form method="post">            
            <label>Seu Nome</label>
            <input type="name" name="nome" required>

            <label>Seu E-mail</label>
            <input type="email" name="email" required>

            <label>Sua Senha</label>
            <input type="password" name="senha" required>

            <button name="logar">Entrar</button>
        </form>

        <div class="erro">
            <?php login($conecta); ?>
        </div>
        <a href="../layout/index.php" class="back-btn">Voltar ao Portal</a>
    </div>

</body>
</html>

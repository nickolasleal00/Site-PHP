<?php
session_start();
require_once "../banco/functions.php";

if (!isset($_SESSION['ativa'])) {
    header("Location: index.php");
    exit;
}


if (isset($_POST['cadastrar'])) {
    $nome = !empty($_POST['nome']) ? $_POST['nome'] : null;
    $email = $_POST['email'];
    $senha = sha1($_POST['senha']); 

    $foto = null;
    if (!empty($_FILES['foto']['name'])) {
        $foto = time() . "_" . $_FILES['foto']['name'];
        move_uploaded_file($_FILES['foto']['tmp_name'], "uploads/" . $foto);
    }

    $sql = "INSERT INTO usuarios (nome, email, senha, foto) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conecta, $sql);
    mysqli_stmt_bind_param($stmt, "ssss", $nome, $email, $senha, $foto);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['mensagem'] = "<p class='msg-sucesso'>Usuário cadastrado com sucesso!</p>";
    } else {
        $_SESSION['mensagem'] = "<p class='msg-erro'>Erro ao cadastrar usuário!</p>";
    }

    header("Location: admin.php");
    exit;
}

$sql = "SELECT id, nome, email, foto FROM usuarios";
$result = mysqli_query($conecta, $sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Painel de Usuários</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
<header class="topbar">
    <h1>Gerenciar Usuários</h1>
</header>

<div class="container">
    <?php 
    if (isset($_SESSION['mensagem'])) { 
        echo $_SESSION['mensagem']; 
        unset($_SESSION['mensagem']); 
    } 
    ?>

    <div class="card">
        <h2>Adicionar Novo Usuário</h2>
        <form method="post" action="" enctype="multipart/form-data">
            <label>Nome (opcional)</label>
            <input type="text" name="nome">

            <label>Email</label>
            <input type="email" name="email" required>

            <label>Senha</label>
            <input type="password" name="senha" required>

            <label>Foto do Usuário</label>
            <input type="file" name="foto" accept="image/*">

            <button type="submit" name="cadastrar" class="btn">Cadastrar</button>
        </form>
    </div>
    <div class="card">
        <h2>Usuários Cadastrados</h2>
        <table>
            <thead>
                <tr>
                    <th>Foto</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td>
                        <?php if(!empty($row['foto']) && file_exists("uploads/".$row['foto'])): ?>
                            <img src="uploads/<?= $row['foto'] ?>" alt="Foto" class="foto-perfil">
                        <?php else: ?>
                            <img src="uploads/default.png" alt="Foto" class="foto-perfil">
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($row['nome'] ? $row['nome'] : "Usuário") ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td>
                        <a href="editar.php?email=<?= urlencode($row['email']) ?>" class="btn-editar">Editar</a>
                        <a href="excluir.php?email=<?= urlencode($row['email']) ?>" onclick="return confirm('Tem certeza que deseja excluir este usuário?')" class="btn-excluir">Excluir</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <a href="../banco/index.php" class="back-btn">Voltar ao painel</a>
</div>
</body>
</html>

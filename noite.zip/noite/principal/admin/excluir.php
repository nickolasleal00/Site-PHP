<?php
require_once "../banco/functions.php";

if (!isset($_GET['email'])) {
    header("Location: admin.php");
    exit;
}

$email = $_GET['email'];

$sql = "SELECT foto FROM usuarios WHERE email = ?";
$stmt = mysqli_prepare($conecta, $sql);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if ($user['foto'] && file_exists("uploads/" . $user['foto'])) {
    unlink("uploads/" . $user['foto']);
}


$sql = "DELETE FROM usuarios WHERE email = ?";
$stmt = mysqli_prepare($conecta, $sql);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);

header("Location: admin.php?delete=ok");
exit;
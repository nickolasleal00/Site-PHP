<?php
session_start();
require_once "../banco/functions.php";

if (!isset($_GET['email'])) {
    die("Email não informado!");
}

$emailOriginal = $_GET['email'];

$sql = "SELECT * FROM usuarios WHERE email = ?";
$stmt = mysqli_prepare($conecta, $sql);
mysqli_stmt_bind_param($stmt, "s", $emailOriginal);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$usuario = mysqli_fetch_assoc($result);

if (!$usuario) {
    die("Usuário não encontrado!");
}

if (isset($_POST['salvar'])) {

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $fotoNova = $usuario['foto']; 

    // Se enviou nova foto
    if (!empty($_FILES['foto']['name'])) {
        $fotoNova = time() . "_" . $_FILES['foto']['name'];
        move_uploaded_file($_FILES['foto']['tmp_name'], "uploads/" . $fotoNova);

        // excluir foto antiga se existir
        if (!empty($usuario['foto']) && file_exists("uploads/" . $usuario['foto'])) {
            unlink("uploads/" . $usuario['foto']);
        }
    }

    $sql2 = "UPDATE usuarios SET nome = ?, email = ?, foto = ? WHERE email = ?";
    $stmt2 = mysqli_prepare($conecta, $sql2);
    mysqli_stmt_bind_param($stmt2, "ssss", $nome, $email, $fotoNova, $emailOriginal);

    mysqli_stmt_execute($stmt2);

    header("Location: admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuário</title>
    <link rel="stylesheet" href="editar.css">
</head>
<body>

<div class="container">
    <h2>Editar Usuário</h2>

    <form action="editar.php?email=<?php echo $usuario['email']; ?>" method="POST" enctype="multipart/form-data">

        <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">

        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo $usuario['nome']; ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $usuario['email']; ?>" required>

        <label>Senha (deixe vazio para não alterar):</label>
        <input type="password" name="senha">

        <label>Foto Atual:</label>
        <div class="foto-preview">
            <img src="uploads/<?php echo $usuario['foto']; ?>" id="preview" alt="Foto de perfil">
        </div>

        <label>Alterar Foto:</label>
        <input type="file" name="foto" accept="image/*" onchange="mostrarPreview(event)">

        <button type="submit" name="salvar">Salvar Alterações</button>
    </form>
</div>

<script>
function mostrarPreview(event) {
    const imagem = document.getElementById("preview");
    imagem.src = URL.createObjectURL(event.target.files[0]);
}
</script>

</body>
</html>
